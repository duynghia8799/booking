
<?php $__env->startSection('title-page'); ?>
	Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-page'); ?>
<!-- BEGIN: Subheader -->
<div class="m-subheader ">
    <div class="d-flex align-items-center">
        <div class="mr-auto">
            <h3 class="m-subheader__title ">
                Dashboard
            </h3>
        </div>
    </div>
</div>
<!-- END: Subheader -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\massage\resources\views/admin/index.blade.php ENDPATH**/ ?>