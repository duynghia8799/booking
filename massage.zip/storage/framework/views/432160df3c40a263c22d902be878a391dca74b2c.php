<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
            <meta content="IE=edge" http-equiv="X-UA-Compatible">
                <title>
                </title>
            </meta>
        </meta>
    </head>
    <body>
        <h2>
            Lịch hẹn
        </h2>
        <table border="0" cellpadding="10">
            <tbody>
                <tr>
                    <td colspan="2">
                        <b>
                            Thông tin khách hàng
                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Họ và tên
                    </td>
                    <td>
                        <b>
                            <?php echo e($dataSendMail['fullname']); ?>

                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Số điện thoại
                    </td>
                    <td>
                    	<b>
                        	<?php echo e($dataSendMail['phone']); ?>

                        </b>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <b>
                            Thông tin lịch đặt
                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Khung giờ bắt đầu
                    </td>
                    <td>
                    	<b>
                        	<?php echo e($dataSendMail['start_at']); ?>

                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Nhân viên đã chọn
                    </td>
                    <td>
                    	<b>
                            <?php if($dataSendMail['staff'] != ''): ?>
    	                        <?php $__currentLoopData = $dataSendMail['staff']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    								<?php echo e($staff->name); ?> <br>
    	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                Chưa chọn
                            <?php endif; ?>
                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Dịch vụ đã chọn
                    </td>
                    <td>
                    	<b>
	                        <?php $__currentLoopData = $dataSendMail['service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php echo e($service->name); ?> <br>
	                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </b>
                    </td>
                </tr>
                <tr>
                    <td>
                        Ghi chú
                    </td>
                    <td>
                    	<b>
                        	<?php echo e($dataSendMail['note']); ?>

                        </b>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\massage\resources\views/email/index.blade.php ENDPATH**/ ?>