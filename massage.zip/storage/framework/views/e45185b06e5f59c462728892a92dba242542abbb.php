<?php $__env->startSection('title-page'); ?>
    Đăng nhập
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="m-grid m-grid--hor m-grid--root m-page">
            <div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor m-login m-login--signin m-login--2 m-login-2--skin-1" id="m_login" style="background-image: url(<?php echo e(asset('/template/metronic/assets/app/media/img/bg/bg-1.jpg')); ?>);">
                <div class="m-grid__item m-grid__item--fluid m-login__wrapper">
                    <div class="m-login__container">
                        <div class="m-login__signin">
                            <div class="m-login__head">
                                <h3 class="m-login__title">Login to Admin</h3>
                            </div>
                            <?php if(session('login-error')): ?>
                                <b class="text-danger">Tên đăng nhập hoặc mật khẩu không đúng</b>
                            <?php endif; ?>
                            <form class="m-login__form m-form" action="<?php echo e(route('login')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group m-form__group">
                                    <input class="form-control m-input" type="text" placeholder="Email" name="email" autocomplete="off" value="<?php echo e(old('email')); ?>">
                                    <?php if($errors->has('email')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group m-form__group">
                                    <input class="form-control m-input m-login__form-input--last" type="password" placeholder="<?php echo e(__('Enter password')); ?>" name="password">
                                    <?php if($errors->has('password')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="row m-login__form-sub">
                                    <div class="col m--align-left m-login__form-left">
                                        <label class="m-checkbox  m-checkbox--light">
                                            <input class="form-check-input" type="checkbox" name="remember" id="remember"><?php echo e(__('Ghi nhớ tôi')); ?>

                                            <span></span>
                                        </label>
                                    </div>
                                    <div class="col m--align-right m-login__form-right">
                                        <?php if(Route::has('password.request')): ?>
                                            <a id="m_login_forget_password" class="m-link" href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Quên mật khẩu?')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="m-login__form-action">
                                    <button id="m_login_signin_submit" class="btn btn-focus m-btn m-btn--pill m-btn--custom m-btn--air  m-login__btn m-login__btn--primary">Đăng nhập</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\massage\resources\views/auth/login.blade.php ENDPATH**/ ?>