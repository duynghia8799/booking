<!-- begin::Head -->
<head>
    <meta charset="utf-8" />
    <title>
        <?php echo $__env->yieldContent('title-page'); ?>
    </title>
    <meta name="description" content="Latest updates and statistic charts">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
    
    <script>
        WebFont.load({
            google: {
                "families": ["Roboto:300,400,500,600,700", "Poppins:300,400,500,600,700"]
            },
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.21/datatables.min.css"/>
    <link href="<?php echo e(asset('/template/metronic/assets/vendors/custom/fullcalendar/fullcalendar.bundle.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('/template/metronic/assets/vendors/base/vendors.bundle.css')); ?>" rel="stylesheet" type="text/css" />

    <link href="<?php echo e(asset('/template/metronic/assets/demo/default/base/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
</head>

<!-- end::Head -->
<?php /**PATH C:\xampp\htdocs\massage\resources\views/admin/layout/common/head.blade.php ENDPATH**/ ?>