<?php

return [
    'status' => [
        'active' => 1,
        'cancel' => 0,
    ],
    'image' => [
        'logo' => '/images/logo.png',
    ],
];

?>