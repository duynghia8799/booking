@extends('admin.layout.master')
@section('title-page')
	Trang chủ
@endsection
@section('content-page')
<!-- BEGIN: Subheader -->
<div class="m-subheader ">
    <div class="d-flex align-items-center">
        <div class="mr-auto">
            <h3 class="m-subheader__title ">
                Dashboard
            </h3>
        </div>
    </div>
</div>
<!-- END: Subheader -->
@endsection
