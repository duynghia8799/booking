<html>
@include ('admin.layout.common.head')
<body class="m--skin- m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--fixed m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default">
@yield('content')
@include ('admin.layout.common.bottom')
</body>
</html>